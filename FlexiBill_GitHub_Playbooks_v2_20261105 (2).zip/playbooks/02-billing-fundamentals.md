# 02 — Billing Fundamentals

## Core concepts
- **Customer/member:** the person or business being billed.
- **Merchant:** the biller or service provider.
- **Collection:** a grouping or commercial offering used to organize billing.
- **Plan:** the pricing and billing rule attached to an offering.
- **Subscription/membership:** the customer's recurring relationship.
- **Invoice/bill:** the amount due for a billing period or event.
- **Payment attempt:** an attempt to collect the amount due.
- **Dunning/recovery:** actions after a failed or overdue collection.

## Explain the lifecycle
Offer → customer enrollment → billing schedule → invoice generation → payment attempt → success or failure → retry/recovery → renewal, cancellation or expiry.

## Authoring note
Add approved product-specific terminology and screenshots from the current source documentation.
