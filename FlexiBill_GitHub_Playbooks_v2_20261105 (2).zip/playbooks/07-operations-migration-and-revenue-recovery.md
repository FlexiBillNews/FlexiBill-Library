# 07 — Operations, Migration & Revenue Recovery

## Operating lifecycle
Onboarding → billing run → payment monitoring → exception handling → retry/recovery → reconciliation → renewal/expiry → support.

## Migration workstream
Inventory merchants and billing models; map members, plans, schedules and payment tokens; identify unsupported configurations; define cutover and rollback; reconcile opening balances; run parallel validation; obtain merchant sign-off.

## Revenue leakage framework
Track active billings, amount due, attempts, success rate, failed amount, recovery rate, days to recovery, never-succeeded population, lapse/churn and recovered TPV/revenue.

## Operational controls
Ownership, escalation SLA, retry policy, customer communication, reconciliation, incident logging and data access controls.
