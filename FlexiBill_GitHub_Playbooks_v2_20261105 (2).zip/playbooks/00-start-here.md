# 00 — Start Here: FlexiBill Handbook

## What this library is
The internal operating handbook for understanding, positioning, configuring, selling, integrating and improving DOKU FlexiBill across Indonesia and Malaysia.

## Choose your path
- **Discover:** 01 Product Strategy & Vision
- **Understand:** 02 Billing Fundamentals and 03 Capabilities
- **Sell:** 05 Sales & Industry Playbooks
- **Implement:** 04 Merchant Solution and 06 Technical Integration
- **Operate:** 07 Operations, Migration & Revenue Recovery
- **Localize:** 08 Country Playbooks
- **Explore:** 09 Innovation & Future Products

## Product truth rule
Separate generally available capabilities, configuration-dependent capabilities, integration-dependent capabilities, roadmap items and concepts. Never present a proposal as a live feature.
