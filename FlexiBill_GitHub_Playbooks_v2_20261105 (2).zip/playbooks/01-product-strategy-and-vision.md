# 01 — Product Strategy & Vision

## Strategic positioning
Position FlexiBill as a billing and subscription orchestration capability connected to DOKU payment rails. Explain the merchant problem first, then the billing model, payment method and operating outcome.

## Core narrative
- Make recurring and scheduled billing easier to launch and operate.
- Connect billing events to payment collection and recovery.
- Support both DOKU-hosted billing automation and merchant-controlled recurring integrations, subject to the approved product scope.

## Strategy content to complete
- Vision, mission and target segments
- 2026–2027 roadmap and prioritization logic
- Product boundaries versus payment automation
- Competitive benchmark and differentiation
- KPI tree: activation, active billings, collection success, recovery, retention, TPV and revenue

## Source mapping
Roadmap Refresh 2H 2026; Capability Map 2027; Beyond Payment Gateway deck.
