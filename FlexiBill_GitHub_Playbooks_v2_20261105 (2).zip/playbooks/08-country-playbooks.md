# 08 — Country Playbooks: Indonesia & Malaysia

Shared product truth lives in playbooks 01–07. This section captures only country-specific differences.

For each country document:
- Supported payment methods and rails
- Local regulatory/compliance considerations
- Merchant onboarding and contracting
- Tax, invoicing and settlement differences
- Local operating contacts and escalation
- Local case studies, pricing and sales collateral
- Known product or integration differences

See `countries/indonesia/` and `countries/malaysia/`.
