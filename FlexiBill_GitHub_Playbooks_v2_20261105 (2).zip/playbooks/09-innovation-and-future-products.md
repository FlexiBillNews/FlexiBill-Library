# 09 — Innovation & Future Products

## Purpose
A controlled space for concepts, discovery and roadmap proposals. Content here is not a statement of production availability.

## Bill Connector concept
Explore a cross-merchant bill-payment hub: a customer-facing identity or payment reference that can surface bills from participating merchants, support bill selection and payment, and potentially support auto-debit and merchant privileges.

## Discovery questions
- Bill discovery, consent and customer identity
- Unique reference / VA model and bank-rail coverage
- Merchant participation and biller onboarding
- One-bill versus multi-bill payment
- Auto-debit mandate and revocation
- Reconciliation, refunds, disputes and liability
- Commercial model, partnership model and regulatory assessment

## Stage gates
Problem validation → feasibility → partner validation → prototype → controlled pilot → launch decision.
