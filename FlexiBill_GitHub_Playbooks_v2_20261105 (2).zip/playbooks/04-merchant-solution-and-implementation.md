# 04 — Merchant Solution & Implementation

## Standard implementation journey
Discover → qualify → design billing model → confirm payment method → configure → integrate → test → pilot → launch → monitor.

## Solution design questions
- Who is billed and who owns the customer relationship?
- Is billing fixed, usage-based, installment-based or subscription-based?
- Who calculates the amount?
- Who initiates payment and manages retries?
- Which customer self-service actions are required?
- What are the reconciliation and support requirements?

## Required implementation artefacts
Solution brief, billing flow, field mapping, configuration record, API/event mapping, test cases, operational runbook, go-live checklist and owner matrix.
