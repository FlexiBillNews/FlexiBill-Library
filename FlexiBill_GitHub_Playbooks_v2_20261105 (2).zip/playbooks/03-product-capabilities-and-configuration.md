# 03 — Product Capabilities & Configuration

Organize capability guidance by merchant job, not by internal screen.

## Capability domains
1. Merchant and member setup
2. Collections, plans and pricing models
3. Pricing table and customer enrollment
4. Subscription schedules and billing rules
5. Payment methods and auto-debit
6. Invoice, receipt and notification
7. Member Center and Billing Portal
8. Coupons, tax and promotions
9. Monitoring, reporting and exports

## Pricing models to document
Flat fee, per unit, tiered, volume, stairstep and open amount — clearly state availability and configuration constraints for each.

## Configuration checklist
For every capability document: purpose, prerequisites, user roles, configuration steps, customer experience, edge cases, limitations, API dependency and evidence/source.
