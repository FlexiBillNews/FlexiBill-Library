# 05 — Sales & Industry Playbooks

## Sales conversation
1. Understand the merchant's billing problem.
2. Quantify missed collections, manual work and customer friction.
3. Map the current billing lifecycle.
4. Recommend the simplest viable FlexiBill model.
5. Validate integration, payment and operational dependencies.
6. Agree success metrics and pilot scope.

## Industry lenses
- Insurance: premium collection, renewals, persistency and failed-payment recovery.
- Education: tuition schedules, installments and parent/student communication.
- SaaS: recurring plans, upgrades/downgrades and churn prevention.
- Travel/hospitality: deposits, scheduled payments and installment collection.
- SME: repeat invoices, membership and lightweight automation.
- Lending/embedded platforms: scheduled repayment collection, subject to risk and regulatory review.

## Sales assets to complete
Discovery questions, qualification scorecard, use-case cards, ROI calculator, objection handling, demo script and proposal template.
