# 06 — Technical & Integration Guide

## Integration patterns
Document each supported pattern separately:
- Dashboard/no-code configuration
- API-driven merchant-hosted recurring billing
- Batch/SFTP, where approved
- Webhooks and event-driven status updates
- Partner/platform integration

## For every API/event
Capture purpose, endpoint/event name, authentication, required fields, optional fields, idempotency, response codes, retry behavior, security, sample payload and version.

## Technical flow
Merchant system → FlexiBill billing orchestration → payment instruction → DOKU payment rail → status/event → merchant system and operational reporting.

## Source of truth
Use the approved H2H API workbook and Merchant Recurring API V2 documentation. Do not infer endpoint behavior from diagrams alone.
