# FlexiBill Internal Playbooks

A modular, GitHub-ready knowledge base for DOKU FlexiBill (Indonesia + Malaysia).

## Start here
1. Read `playbooks/00-start-here.md`.
2. Use the relevant playbook for your role.
3. Check country overlays for Indonesia or Malaysia.
4. Treat future concepts as proposals, not production capabilities.

## Repository map
- `playbooks/` — shared product, sales, implementation and operating guidance
- `countries/` — country-specific overlays
- `governance/` — ownership, review and publishing rules
- `templates/` — reusable playbook template

## Important
This is a starter structure. It organizes the knowledge base and identifies where source material should be incorporated; it is not a claim that every source document has already been fully converted into final playbook content.
