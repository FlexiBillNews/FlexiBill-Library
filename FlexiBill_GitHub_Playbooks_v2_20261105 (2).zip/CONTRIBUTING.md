# Contributing

1. Create a branch for each meaningful update.
2. Edit the relevant Markdown playbook; avoid duplicating shared content in country folders.
3. Add source references and mark assumptions clearly.
4. Submit a pull request using the repository template.
5. Product owns product truth; Engineering reviews technical accuracy; country teams review local applicability.
