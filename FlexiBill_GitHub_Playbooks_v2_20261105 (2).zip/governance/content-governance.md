# Content Governance

## Ownership
- Product: product truth, roadmap and capability scope
- Engineering: API, integration and technical accuracy
- Sales/Partnership: industry use cases and commercial playbooks
- Indonesia and Malaysia leads: local applicability
- Library owner: structure, publishing and archival

## Status labels
Draft → In Review → Approved → Published → Superseded → Archived.

## Review cadence
Review critical product and technical content monthly; review the full library quarterly and whenever a product/API release materially changes guidance.

## Required metadata
Owner, reviewer, status, version, last-reviewed date, source links and country applicability.
