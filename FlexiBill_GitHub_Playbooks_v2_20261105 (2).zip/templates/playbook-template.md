# [Playbook title]

**Owner:**  
**Reviewer:**  
**Status:** Draft  
**Version:** 0.1  
**Last reviewed:** YYYY-MM-DD  
**Applicability:** Indonesia / Malaysia / Shared

## Purpose
What this playbook helps the reader accomplish.

## When to use
Audience, trigger and prerequisites.

## Recommended process
Numbered steps with decision points.

## Customer / merchant experience
Describe the end-to-end journey.

## Configuration / technical detail
Add only verified instructions and link to approved source documentation.

## Risks and limitations
State dependencies, exclusions and known gaps.

## Checklist
- [ ] Required preparation
- [ ] Validation
- [ ] Approval
- [ ] Handover

## Sources
Link approved source documents and record version/date.
