# Source Materials Index

Map existing approved source documents into the repository. Preserve originals in the approved DOKU Shared Drive and link them from the relevant playbook.

| Source material | Target playbook |
|---|---|
| Roadmap Refresh 2H 2026 | 01 Product Strategy |
| Merchant Process / Capability Map 2027 | 01, 03, 04 |
| Merchant Implementation Playbook 2027 | 04 |
| Beyond Payment Gateway Sales Deck | 01, 05 |
| Vertical Sales Playbook | 05 |
| SME Sales Playbook | 05 |
| Indonesia SME Strategy / Presentation | 05 + Indonesia overlay |
| Malaysia Presentation / Merchant Guide | 08 + Malaysia overlay |
| H2H API FlexiBill Workbook | 06 |
| Merchant Recurring API V2 | 06 |
| Merchant Migration Guideline | 04, 07 |
| Indonesia vs Malaysia Comparison | 08 |
| Bill Connector Blueprint | 09 — concept only; not production capability |

Add each source's approved Drive URL, owner, version and last-reviewed date before publishing.
